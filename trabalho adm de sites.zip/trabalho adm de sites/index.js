// bt 1
function abrir(){
    document.getElementById("fundoModal").style.display = "block";
}
function fechar(){
    document.getElementById("fundoModal").style.display="none";
}
// bt 2
function abrir2(){
    document.getElementById("fundoModal 2").style.display = "block";
}
function fechar2(){
    document.getElementById("fundoModal 2").style.display="none";
}
// bt 3
function abrir3(){
    document.getElementById("fundoModal 3").style.display = "block";
}
function fechar3(){
    document.getElementById("fundoModal 3").style.display="none";
}
// bt 4
function abrir4(){
    document.getElementById("fundoModal 4").style.display = "block";
}
function fechar4(){
    document.getElementById("fundoModal 4").style.display="none";
}
// bt 5
function abrir5(){
    document.getElementById("fundoModal 5").style.display = "block";
}
function fechar5(){
    document.getElementById("fundoModal 5").style.display="none";
}
// bt 6
function abrir6(){
    document.getElementById("fundoModal 6").style.display = "block";
}
function fechar6(){
    document.getElementById("fundoModal 6").style.display="none";
}
// bt 7
function abrir7(){
    document.getElementById("fundoModal 7").style.display = "block";
}
function fechar7(){
    document.getElementById("fundoModal 7").style.display="none";
}
// bt 8
function abrir8(){
    document.getElementById("fundoModal 8").style.display = "block";
}
function fechar8(){
    document.getElementById("fundoModal 8").style.display="none";
}
// bt 9
function abrir9(){
    document.getElementById("fundoModal 9").style.display = "block";
}
function fechar9(){
    document.getElementById("fundoModal 9").style.display="none";
}
// bt 10
function abrir10(){
    document.getElementById("fundoModal 10").style.display = "block";
}
function fechar10(){
    document.getElementById("fundoModal 10").style.display="none";
}

function abrirs(){
    document.getElementById('buts').style.display='block';
}
function fechars(){
    document.getElementById('buts').style.display="none"
}